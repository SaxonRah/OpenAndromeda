//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WinDV.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DVTOOLS_DIALOG              102
#define IDS_CONFIG_DLG                  102
#define IDS_USAGE                       103
#define IDR_MAINFRAME                   128
#define IDD_VIDEODEVICESEL              129
#define IDD_CAPTURE_CONFIG              130
#define IDD_RECORD_CONFIG               131
#define IDI_MINIDV                      132
#define IDI_WINDV                       132
#define IDR_MANIFEST                    1
#define IDS_TAB_VIDEO_CAPTURE           201
#define IDS_TAB_VIDEO_RECORDING         202
#define IDC_TOOL_TAB                    1001
#define IDC_VSRC_SEL                    1002
#define IDC_VSRC_L                      1003
#define IDC_SUFFIX_SEL                  1003
#define IDC_VSRC                        1004
#define IDC_FSRC_L                      1010
#define IDC_FSRC                        1011
#define IDC_FSRC_SEL                    1012
#define IDC_CAPTURE                     1013
#define IDC_CONFIG                      1014
#define IDC_FDST_L                      1015
#define IDC_DEVLIST                     1015
#define IDC_FDST                        1016
#define IDC_FDST_SEL                    1017
#define IDC_VDST_L                      1018
#define IDC_VDST                        1019
#define IDC_VDST_SEL                    1020
#define IDC_RECORD                      1022
#define IDC_STATUS                      1023
#define IDC_VIDEO                       1025
#define IDC_STATUS2                     1026
#define IDC_STATUS3                     1027
#define IDC_DISCONTINUITY_TRESHOLD      1048
#define IDC_MAX_FRAMES                  1049
#define IDC_EVERY_NTH                   1050
#define IDC_TYPE_1                      1052
#define IDC_TYPE_2                      1053
#define IDC_AVI_PREFIX                  1054
#define IDC_AVI_SUFFIX                  1055
#define IDC_EMAIL                       1060
#define IDC_URL                         1061
#define IDC_CUSTOM1                     1062
#define IDC_PICTURE                     1063
#define IDC_RECORDPREVIEW               1064
#define IDC_COUNTER                     1065
#define IDC_PREFIX_SEL                  1066
#define IDC_DTFORMAT                    1068
#define IDC_NDIGITS                     1069
#define IDC_FEXAMPLE                    1070
#define IDC_DVCTRL                      1071

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1072
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
