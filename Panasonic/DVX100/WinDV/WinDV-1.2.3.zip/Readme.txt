     
    WinDV            http://windv.mourek.cz


A small Windows utility for DV (FireWire digital video) input/output.
---------------------------------------------------------------------

Author: Petr Mourek, Czech Republic     E-mail: petr@mourek.cz

Please feel free to send me any comments, questions and/or requests.

If you use my program (successfully or not), 
give me some feedback, please.


Main features (more information on the WinDV web-page):
-------------------------------------------------------

small & handy <100kB one-file WinDV.exe

input / output 
    capturing from DV device to AVI files (both type-1 and type-2) 
    and recording vice versa

no dropped frames - memory buffering

automatic AVI splitting according to the timestamps on DV recordings 
    every video sequence can be saved into unique file

easy AVI joining 
    record multiple files joined to the DV device just using wildcards

preview of transmitted video in the window

free - you can use it as you like at no cost

--------------------------------
Copyright (C) Petr Mourek 2002-2003
